import { Holidays, HolidaysModel } from './holidays.model';

describe('Holidays', () => {
  it('should create an instance', () => {
    expect(new Holidays()).toBeTruthy();
  });
});
